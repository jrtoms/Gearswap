function user_job_setup()

--organizer stuff
include('organizer-lib')
organizer_items = {
  echos="Echo Drops",
  shihei="Shihei",
  orb="Macrocosmic Orb",
  attackfood="Red Curry Bun",
  maccfood="Tropical Crepe",
  accfood="Sublime Sushi",
}

  -- Options: Override default values
    state.OffenseMode:options('Normal','SomeAcc','Acc','FullAcc','Fodder', 'PDT')
    state.WeaponskillMode:options('Match','Normal','SomeAcc','Acc','FullAcc','Fodder')
    state.HybridMode:options('Normal', 'HybridDT')
    state.PhysicalDefenseMode:options('PDT', 'PDTReraise')
    state.MagicalDefenseMode:options('MDT', 'MDTReraise')
	  state.ResistDefenseMode:options('MEVA')
	  state.IdleMode:options('Normal', 'PDT','Refresh','Reraise')
    state.ExtraMeleeMode = M{['description']='Extra Melee Mode','None'}
	  state.Passive = M{['description'] = 'Passive Mode','None','Twilight'}
	  state.Weapons:options('Ukonvasara',
                          'Chango',
                          'DualWeapons',
                          'Greatsword',
                          'ProcDagger',
                          'ProcSword',
                          'ProcGreatSword',
                          'ProcScythe',
                          'ProcPolearm',
                          'ProcKatana',
                          'ProcGreatKatana',
                          'ProcClub',
                          'ProcStaff',
                          'ShiningOne',
                          'MurderClub',
                          'SwordAndBoard',
                          'LatentBreak'
                        )

	gear.da_jse_back = {name="Cichol's Mantle",augments={'STR+20','Accuracy+20 Attack+20','"Dbl.Atk."+10'}}
	gear.crit_jse_back = {name="Cichol's Mantle",augments={'STR+20','Accuracy+20 Attack+20','Crit.hit rate+10'}}

	-- Additional local binds
  send_command('gs c set Weapons Ukonvasara')
	send_command('bind ^` input /ja "Hasso" <me>')
	send_command('bind !` input /ja "Seigan" <me>')
	send_command('bind @` gs c cycle SkillchainMode')
	send_command('bind !r gs c weapons Greatsword;gs c update')
  send_command('lua l xivhotbar')
  send_command('gs org')

  lockstyleset = 014

  set_lockstyle()
	select_default_macro_book()
end

function user_unload()
    send_command('lua u xivhotbar')

end

-- Define sets and vars used by this job file.
function init_gear_sets()
	--------------------------------------
	-- Start defining the sets
	--------------------------------------
	-- Precast Sets

  sets.Enmity = {
    ammo="Aqreqaq Bomblet",
    head="Pummeler's Mask +3",
    body="Souveran Cuirass",
    hands="Pumm. Mufflers +3",
    legs={ name="Odyssean Cuisses", augments={'Mag. Acc.+14 "Mag.Atk.Bns."+14','"Store TP"+5','Crit.hit rate+5',}},
    feet="Sakpata's Leggings",
    neck="Moonlight Necklace",
    waist="Goading Belt",
    left_ear="Trux Earring",
    right_ear="Friomisi Earring",
    left_ring="Apeile Ring +1",
    right_ring="Eihwaz Ring",
    back="Philidor Mantle",
  }
	sets.Knockback = {}
	sets.passive.Twilight = {head="Twilight Helm",body="Twilight Mail"}

	-- Precast sets to enhance JAs
	sets.precast.JA.Berserk = {body="Pumm. Lorica +3",feet="Agoge Calligae +2"}
	sets.precast.JA['Warcry'] = {head="Agoge Mask +3"}
	sets.precast.JA['Defender'] = {}
	sets.precast.JA['Aggressor'] = {head="Pummeler's Mask +3",body="Agoge Lorica +3"}
	sets.precast.JA['Mighty Strikes'] = {hands="Agoge Mufflers +1"}
	sets.precast.JA["Warrior's Charge"] = {}
	sets.precast.JA['Tomahawk'] = {ammo="Thr. Tomahawk",feet="Agoge Calligae +2"}
	sets.precast.JA['Retaliation'] = {}
	sets.precast.JA['Restraint'] = {}
	sets.precast.JA['Blood Rage'] = {body="Boii Lorica +1"}
	sets.precast.JA['Brazen Rush'] = {}
	sets.precast.JA['Provoke'] = set_combine(sets.Enmity,{})

	-- Waltz set (chr and vit)
	sets.precast.Waltz = {}

	-- Don't need any special gear for Healing Waltz.
	sets.precast.Waltz['Healing Waltz'] = {}

	sets.precast.Step = {}

	sets.precast.Flourish1 = {}

	-- Fast cast sets for spells

	sets.precast.FC = {ammo="Impatiens",
		head="Carmine Mask +1",
    neck="Voltsurge Torque",
    ear1="Enchntr. Earring +1",
    ear2="Loquac. Earring",
		body="Odyss. Chestplate",
    hands="Leyline Gloves",
    ring1="Lebeche Ring",
    ring2="Prolix Ring",
		back="Moonlight Cape",
    waist="Flume Belt +1",
    legs=gear.odyssean_fc_legs,
    feet="Odyssean Greaves"}

	sets.precast.FC.Utsusemi = set_combine(sets.precast.FC, {})

	-- Midcast Sets
	sets.midcast.FastRecast = {
    ammo="Staunch Tathlum +1",
		head="Carmine Mask +1",
    neck="Voltsurge Torque",ear1="Enchntr. Earring +1",ear2="Loquac. Earring",
		body="Odyss. Chestplate",hands="Leyline Gloves",ring1="Lebeche Ring",ring2="Prolix Ring",
		back="Moonlight Cape",waist="Tempus Fugit",legs=gear.odyssean_fc_legs,feet="Odyssean Greaves"}

	sets.midcast.Utsusemi = set_combine(sets.midcast.FastRecast, {back="Mujin Mantle"})

	sets.midcast.Cure = {}

	sets.Self_Healing = {neck="Phalaina Locket",hands="Buremte Gloves",ring2="Kunaji Ring",waist="Gishdubar Sash"}
	sets.Cure_Received = {neck="Phalaina Locket",hands="Buremte Gloves",ring2="Kunaji Ring",waist="Gishdubar Sash"}

	-- Weaponskill sets
	-- Default set for any weaponskill that isn't any more specifically defined
  sets.precast.WS = {

  }

	sets.precast.WS.SomeAcc = set_combine(sets.precast.WS, {
    head="Flamma Zucchetto +2",
    legs={ name="Odyssean Cuisses", augments={'Attack+18','Weapon skill damage +3%','Accuracy+7'}},
    ammo="Focal Orb",
  })
	sets.precast.WS.Acc = set_combine(sets.precast.WS, {})
	sets.precast.WS.FullAcc = set_combine(sets.precast.WS, {
    left_ring="Flamma Ring",
    right_ring="Mouflon Ring",
    left_ear="Mache Earring +1",
    right_ear="Mache Earring +1",
    ammo="Seething Bomblet",
  })
	sets.precast.WS.Fodder = set_combine(sets.precast.WS, {})

    -- Specific weaponskill sets.  Uses the base set if an appropriate WSMod version isn't found.

    sets.precast.WS["Ukko's Fury"] = set_combine(sets.precast.WS, {
      ammo="Yetshila +1",
      head={ name="Valorous Mask", augments={'Accuracy+29','Crit.hit rate+3','Attack+7',}},
      body={ name="Valorous Mail", augments={'Accuracy+22 Attack+22','Crit.hit rate+4','STR+6',}},
      hands="Flam. Manopolas +2",
      legs={ name="Valorous Hose", augments={'Accuracy+11 Attack+11','Crit.hit rate+4','CHR+15',}},
      feet="Sulev. Leggings +2",
      neck="Fotia Gorget",
      waist="Fotia Belt",
      left_ear={ name="Moonshade Earring", augments={'Accuracy+4','TP Bonus +250',}},
      right_ear="Brutal Earring",
      left_ring="Niqmaddu Ring",
      right_ring="Regal Ring",
      back={ name="Cichol's Mantle", augments={'STR+20','Accuracy+20 Attack+20','Accuracy+10','Crit.hit rate+10',}},
    })

    sets.precast.WS["Ukko's Fury"].SomeAcc = set_combine(sets.precast.WS["Ukko's Fury"], {
      head={ name="Argosy Celata +1", augments={'STR+12','DEX+12','Attack+20',}},
      body={ name="Argosy Hauberk +1", augments={'STR+12','DEX+12','Attack+20',}},
      hands={ name="Argosy Mufflers +1", augments={'STR+20','"Dbl.Atk."+3','Haste+3%',}},
      feet="Pumm. Calligae +3",
    })
    sets.precast.WS["Ukko's Fury"].Acc = set_combine(sets.precast.WS["Ukko's Fury"].SomeAcc, {
      ammo="Ginsen",
      head="Pummeler's Mask +3",
      body="Pumm. Lorica +3",
      hands="Pumm. Mufflers +3",
      legs="Pumm. Cuisses +3",
      feet="Pumm. Calligae +3",
      left_ear="Mache Earring +1",
      right_ear="Mache Earring +1",
    })
    sets.precast.WS["Ukko's Fury"].FullAcc = set_combine(sets.precast.WS.FullAcc, {})
    sets.precast.WS["Ukko's Fury"].Fodder = set_combine(sets.precast.WS.Fodder, {})

    sets.precast.WS['Upheaval'] = set_combine(sets.precast.WS, {
      ammo="Knobkierrie",
      head={ name="Agoge Mask +3", augments={'Enhances "Savagery" effect',}},
      body="Pumm. Lorica +3",
      hands={ name="Odyssean Gauntlets", augments={'Pet: AGI+8','Weapon skill damage +3%','Accuracy+12 Attack+12','Mag. Acc.+14 "Mag.Atk.Bns."+14',}},
      legs={ name="Odyssean Cuisses", augments={'Accuracy+25 Attack+25','Potency of "Cure" effect received+1%','VIT+14','Attack+11',}},
      feet="Sulev. Leggings +2",
      neck="War. Beads +2",
      waist="Ioskeha Belt +1",
      left_ear={ name="Moonshade Earring", augments={'Accuracy+4','TP Bonus +250',}},
      right_ear="Thrud Earring",
      left_ring="Niqmaddu Ring",
      right_ring="Regal Ring",
      back={ name="Cichol's Mantle", augments={'VIT+20','Accuracy+20 Attack+20','VIT+10','Weapon skill damage +10%',}},
    })

    sets.precast.WS['Upheaval'].SomeAcc = set_combine(sets.precast.WS['Upheaval'], {
      legs={ name="Odyssean Cuisses", augments={'Accuracy+25 Attack+25','Potency of "Cure" effect received+1%','VIT+14','Attack+11',}},
    })

    sets.precast.WS['Upheaval'].Acc = set_combine(sets.precast.WS['Upheaval'].SomeAcc, {
      body="Pumm. Lorica +3",
      hands="Pumm. Mufflers +3",
      legs="Pumm. Cuisses +3",
      feet="Pumm. Calligae +3",
    })

    sets.precast.WS['Upheaval'].FullAcc = set_combine(sets.precast.WS.FullAcc, {})
    sets.precast.WS['Upheaval'].Fodder = set_combine(sets.precast.WS.Fodder, {})

    sets.precast.WS['Savage Blade'] = set_combine(sets.precast.WS['Upheaval'], {
        waist="Fotia Belt",
        neck="War. beads +2",
        hands = "Agoge Mufflers +3",
    })
--[[
    sets.precast.WS['Savage Blade'].HybridDT = set_combine(sets.precast.WS['Upheaval'], {
        waist="Fotia Belt",
        neck="War. beads +2",
        hands = "Agoge Mufflers +3",
    })
--]]
    sets.precast.WS['Savage Blade'].SomeAcc = set_combine(sets.precast.WS.SomeAcc, {})
    sets.precast.WS['Savage Blade'].Acc = set_combine(sets.precast.WS.Acc, {})
    sets.precast.WS['Savage Blade'].FullAcc = set_combine(sets.precast.WS.FullAcc, {})
    sets.precast.WS['Savage Blade'].Fodder = set_combine(sets.precast.WS.Fodder, {})

    sets.precast.WS['Resolution'] = set_combine(sets.precast.WS["Ukko's Fury"], {})
    sets.precast.WS['Resolution'].SomeAcc = set_combine(sets.precast.WS.SomeAcc, {})
    sets.precast.WS['Resolution'].Acc = set_combine(sets.precast.WS.Acc, {})
    sets.precast.WS['Resolution'].FullAcc = set_combine(sets.precast.WS.FullAcc, {})
    sets.precast.WS['Resolution'].Fodder = set_combine(sets.precast.WS.Fodder, {})

    sets.precast.WS['Ruinator'] = set_combine(sets.precast.WS, {})
    sets.precast.WS['Ruinator'].SomeAcc = set_combine(sets.precast.WS.SomeAcc, {})
    sets.precast.WS['Ruinator'].Acc = set_combine(sets.precast.WS.Acc, {})
    sets.precast.WS['Ruinator'].FullAcc = set_combine(sets.precast.WS.FullAcc, {})
    sets.precast.WS['Ruinator'].Fodder = set_combine(sets.precast.WS.Fodder, {})

    sets.precast.WS['Rampage'] = set_combine(sets.precast.WS, {})
    sets.precast.WS['Rampage'].SomeAcc = set_combine(sets.precast.WS.SomeAcc, {})
    sets.precast.WS['Rampage'].Acc = set_combine(sets.precast.WS.Acc, {})
    sets.precast.WS['Rampage'].FullAcc = set_combine(sets.precast.WS.FullAcc, {})
    sets.precast.WS['Rampage'].Fodder = set_combine(sets.precast.WS.Fodder, {})

    sets.precast.WS['Raging Rush'] = set_combine(sets.precast.WS, {})
    sets.precast.WS['Raging Rush'].SomeAcc = set_combine(sets.precast.WS.SomeAcc, {})
    sets.precast.WS['Raging Rush'].Acc = set_combine(sets.precast.WS.Acc, {})
    sets.precast.WS['Raging Rush'].FullAcc = set_combine(sets.precast.WS.FullAcc, {})
    sets.precast.WS['Raging Rush'].Fodder = set_combine(sets.precast.WS.Fodder, {})

    sets.precast.WS["King's Justice"] = set_combine(sets.precast.WS, {})
    sets.precast.WS["King's Justice"].SomeAcc = set_combine(sets.precast.WS.SomeAcc, {})
    sets.precast.WS["King's Justice"].Acc = set_combine(sets.precast.WS.Acc, {})
    sets.precast.WS["King's Justice"].FullAcc = set_combine(sets.precast.WS.FullAcc, {})
    sets.precast.WS["King's Justice"].Fodder = set_combine(sets.precast.WS.Fodder, {})

	-- Swap to these on Moonshade using WS if at 3000 TP
	sets.MaxTP = {ear1="Lugra Earring +1",ear2="Lugra Earring",}
	sets.AccMaxTP = {ear1="Mache Earring +1",ear2="Telos Earring"}
	sets.AccDayMaxTPWSEars = {ear1="Mache Earring +1",ear2="Telos Earring"}
	sets.DayMaxTPWSEars = {ear1="Ishvara Earring",ear2="Brutal Earring",}
	sets.AccDayWSEars = {ear1="Mache Earring +1",ear2="Telos Earring"}
	sets.DayWSEars = {ear1="Brutal Earring",ear2="Moonshade Earring"}

	--Specialty WS set overwrites.
	sets.AccWSMightyCharge = {}
	sets.AccWSCharge = {}
	sets.AccWSMightyCharge = {}
	sets.WSMightyCharge = {}
	sets.WSCharge = {}
	sets.WSMighty = {}

     -- Sets to return to when not performing an action.

     -- Resting sets
     sets.resting = {}

	-- Idle sets
	sets.idle =
    {
      ring1="Karieyh Ring",
      head="Valorous Mask",
      body="Sakpata's Plate",
      hands = "Sakpata's Gauntlets",
      legs="Sakpata's cuisses",
      feet="Sakpata's leggings",
      ring2="Defending Ring",
      waist="Sailfi Belt +1",
    }


	sets.idle.Weak = set_combine(sets.idle, {head="Twilight Helm",body="Twilight Mail"})

	sets.idle.Reraise = set_combine(sets.idle, {head="Twilight Helm",body="Twilight Mail"})

	-- Defense sets
	sets.defense.PDT = {
    ammo="Staunch Tathlum +1",
		head="Genmei Kabuto",
    neck="Twilight Torque",
    ear1="Genmei Earring",
    ear2="Ethereal Earring",
		body="Sulevia's Platemail +2",
    hands="Sulev. Gauntlets +2",
    ring1="Defending Ring",
    ring2="Moonlight Ring",
		back="Shadow Mantle",
    waist="Flume Belt",
    --legs="Sulev. Cuisses +2",
    feet="Amm Greaves"
  }

	sets.defense.PDTReraise = set_combine(sets.defense.PDT, {head="Twilight Helm",body="Twilight Mail"})

	sets.defense.MDT = {ammo="Staunch Tathlum +1",
		head="Genmei Kabuto",neck="Warder's Charm +1",ear1="Genmei Earring",ear2="Ethereal Earring",
		body="Tartarus Platemail",hands="Sulev. Gauntlets +2",ring1="Moonbeam Ring",ring2="Moonlight Ring",
		back="Moonlight Cape",waist="Flume Belt +1",legs="Sulev. Cuisses +2",feet="Amm Greaves"}

	sets.defense.MDTReraise = set_combine(sets.defense.MDT, {head="Twilight Helm",body="Twilight Mail"})

	sets.defense.MEVA = {ammo="Staunch Tathlum +1",
		head="Genmei Kabuto",neck="Warder's Charm +1",ear1="Genmei Earring",ear2="Ethereal Earring",
		body="Tartarus Platemail",hands="Sulev. Gauntlets +2",ring1="Moonbeam Ring",ring2="Moonlight Ring",
		back="Moonlight Cape",waist="Flume Belt +1",legs="Sulev. Cuisses +2",feet="Amm Greaves"}

	sets.Kiting = {}
	sets.Reraise = {head="Twilight Helm",body="Twilight Mail"}
	sets.buff.Doom = set_combine(sets.buff.Doom, {})
	sets.buff.Sleep = {head="Frenzy Sallet"}

            -- Engaged sets
	sets.engaged = {

    ammo="Yetshila +1",
    head="Flamma Zucchetto +2",
    body={ name="Valorous Mail", augments={'Accuracy+22 Attack+22','Crit.hit rate+4','STR+6',}},
    hands={ name="Valorous Mitts", augments={'Accuracy+14 Attack+14','"Store TP"+7','AGI+3',}},
    legs={ name="Odyssean Cuisses", augments={'Mag. Acc.+14 "Mag.Atk.Bns."+14','"Store TP"+5','Crit.hit rate+5',}},
    feet="Pumm. Calligae +3",
    neck="Asperity Necklace",
    waist="Ioskeha Belt +1",
    ear1="Cessance Earring",
    ear2="Brutal Earring",
    left_ring="Regal Ring",
    right_ring="Niqmaddu Ring",
    back={ name="Cichol's Mantle", augments={'STR+20','Accuracy+20 Attack+20','Accuracy+9','"Dbl.Atk."+10',}},

  }

  sets.engaged.SomeAcc = set_combine(sets.engaged,{
    hands="Sulev. Gauntlets +2",
    feet="Pumm. Calligae +3",
    left_ring="Flamma Ring",
    legs="Pumm. Cuusses +3",
  })

  sets.engaged.Acc = set_combine(sets.engaged.SomeAcc, {

    left_ring="Petrov Ring",
    neck="Lissome Necklace",
    body="Dagon Breast.",
    ammo="Ginsen",
  })

  sets.engaged.FullAcc =
    set_combine(sets.engaged, {

  })
  sets.engaged.Fodder = set_combine(sets.engaged,{

  })

  sets.engaged.PDT = set_combine(sets.engaged, {
    sub="Kaja Grip",
    head="Hjarrandi Helm",
    ring1="Defending Ring",
    ring2="Dark Ring",
    neck="Twilight Torque",
  })

  sets.engaged.HybridDT = set_combine(sets.engaged, {
    head="Sakpata's Helm",
    body="Sakpata's Plate",
    hands = "Sakpata's Gauntlets",
    legs="Sakpata's cuisses",
    feet="Sakpata's leggings",
    ring1="Defending Ring",
    waist="Sailfi Belt +1",
  })

  sets.engaged.Acc.HybridDT = set_combine(sets.engaged.HybridDT, {
    neck="War. beads +2",
    ring2="Flamma Ring",
    left_ear="Mache Earring +1",
    right_ear="Mache Earring +1",
    ammo="Seething Bomblet",
  })

  sets.precast.WS.HybridDT = set_combine(sets.precast.WS['Upheaval'], {

  })

  --  Shining One melee sets
    sets.engaged.ShiningOne = set_combine(sets.engaged, {
      ammo="Yetshila +1",
      head="Hjarrandi Helm",
      ear1="Brutal Earring",
      ear2="Cessance Earring",
      body="Agoge Lorica +3",
      hands="Sulev. Gauntlets +2",
      ring1="Niqmaddu Ring",
      ring2="Regal Ring",
      back={ name="Cichol's Mantle", augments={'STR+20','Accuracy+20 Attack+20','Accuracy+9','"Dbl.Atk."+10',}},
      waist="Ioskeha Belt +1",
      legs="Agoge Cuisses +3",
      feet="Pumm. Calligae +3"
    })

    sets.precast.WS['Impulse Drive'] = set_combine(sets.precast.WS['Savage Blade'], {
      neck="Fotia Gorget",
      legs="Sakpata's Cuisses",
      left_ring="Karieyh Ring",
    })

    sets.engaged.ShiningOne.HybridDT = set_combine(sets.engaged.HybridDT, {
      sub="Kaja Grip",
      ring1="Regal Ring",
      ring2="Defending Ring",
      neck="Asperity Necklace",
    })

    sets.engaged.MurderClub = set_combine(sets.engaged, {
      ammo="Ginsen",
      head="Hjarrandi Helm",
      neck="War. beads +2",
      ear1="Brutal Earring",
      ear2="Cessance Earring",
      body="Sakpata's Plate",
      hands = "Agoge Mufflers +3",
      ring1="Niqmaddu Ring",
      ring2="Regal Ring",
      back={ name="Cichol's Mantle", augments={'STR+20','Accuracy+20 Attack+20','Accuracy+9','"Dbl.Atk."+10',}},
      waist="Ioskeha Belt +1",
      legs="Agoge Cuisses +3",
      feet="Pumm. Calligae +3",
    })

    sets.engaged.MurderClub.HybridDT = set_combine(sets.engaged.HybridDT, {
      head="Sakpata's Helm",
      body="Sakpata's Plate",
      legs="Sakpata's cuisses",
      feet="Sakpata's leggings",
      ring1="Defending Ring",
      ring2="Regal Ring",
      waist="Sailfi Belt +1",
      hands = "Agoge Mufflers +3",
    })

    sets.engaged.SwordAndBoard = set_combine(sets.engaged.MurderClub,{})

    sets.engaged.SwordAndBoard.HybridDT = set_combine(sets.engaged.MurderClub.HybridDT, {

    })


-- Shining One melee sets --
    sets.engaged.Conqueror = {
      main="Shining One",
      sub="Utu Grip",
      ammo="Yetshila +1 +1",
      head="Hjarrandi Helm",
      neck="War. Beads +2",
      ear1="Brutal Earring",
      ear2="Cessance Earring",
      body="Agoge Lorica +3",
      hands="Sulev. Gauntlets +2",
      ring1="Niqmaddu Ring",
      ring2="Hetairoi Ring",
      back="Cichol's Mantle",
      waist="Ioskeha Belt +1",
      legs="Agoge Cuisses +3",
      feet="Pumm. Calligae +3"
    }

-- Chango melee sets
  sets.engaged.Chango = set_combine(sets.engaged, {
    ear1="Dedition Earring",
  })
	sets.engaged.Chango.SomeAcc = set_combine(sets.engaged.someAcc, {

  })
	sets.engaged.Chango.Acc = set_combine(sets.engaged.Acc, {

  })
  sets.engaged.Chango.Acc.HybridDT = set_combine(sets.engaged.HybridDT, {
    neck="War. beads +2",
    ring2="Flamma Ring",
    left_ear="Mache Earring +1",
    right_ear="Mache Earring +1",
    ammo="Seething Bomblet",
  })
	sets.engaged.Chango.FullAcc = {}
	sets.engaged.Chango.Fodder = {}
  sets.engaged.Chango.HybridDT = {
    head="Sakpata's Helm",
    body="Sakpata's Plate",
    hands = "Sakpata's Gauntlets",
    legs="Sakpata's cuisses",
    feet="Sakpata's leggings",
    ring1="Defending Ring",
    waist="Sailfi Belt +1",
  }
  sets.engaged.Chango.Adoulin = {}
	sets.engaged.Chango.SomeAcc.Adoulin = {}
	sets.engaged.Chango.Acc.Adoulin = {}
	sets.engaged.Chango.FullAcc.Adoulin = {}
	sets.engaged.Chango.Fodder.Adoulin = {}

    sets.engaged.Chango.AM = {}
	sets.engaged.Chango.SomeAcc.AM = {}
	sets.engaged.Chango.Acc.AM = {}
	sets.engaged.Chango.FullAcc.AM = {}
	sets.engaged.Chango.Fodder.AM = {}

    sets.engaged.Chango.Adoulin.AM = {}
	sets.engaged.Chango.SomeAcc.Adoulin.AM = {}
	sets.engaged.Chango.Acc.Adoulin.AM = {}
	sets.engaged.Chango.FullAcc.Adoulin.AM = {}
	sets.engaged.Chango.Fodder.Adoulin.AM = {}

    sets.engaged.Chango.Charge = {}
	sets.engaged.Chango.SomeAcc.Charge = {}
	sets.engaged.Chango.Acc.Charge = {}
	sets.engaged.Chango.FullAcc.Charge = {}
	sets.engaged.Chango.Fodder.Charge = {}

    sets.engaged.Chango.Adoulin.Charge = {}
	sets.engaged.Chango.SomeAcc.Adoulin.Charge = {}
	sets.engaged.Chango.Acc.Adoulin.Charge = {}
	sets.engaged.Chango.FullAcc.Adoulin.Charge = {}
	sets.engaged.Chango.Fodder.Adoulin.Charge = {}

    sets.engaged.Chango.Charge.AM = {}
	sets.engaged.Chango.SomeAcc.Charge.AM = {}
	sets.engaged.Chango.Acc.Charge.AM = {}
	sets.engaged.Chango.FullAcc.Charge.AM = {}
	sets.engaged.Chango.Fodder.Charge.AM = {}

    sets.engaged.Chango.Adoulin.Charge.AM = {}
	sets.engaged.Chango.SomeAcc.Adoulin.Charge.AM = {}
	sets.engaged.Chango.Acc.Adoulin.Charge.AM = {}
	sets.engaged.Chango.FullAcc.Adoulin.Charge.AM = {}
	sets.engaged.Chango.Fodder.Adoulin.Charge.AM = {}

	sets.engaged.Chango.PDT = {}
	sets.engaged.Chango.SomeAcc.PDT = {}
	sets.engaged.Chango.Acc.PDT = {}
	sets.engaged.Chango.FullAcc.PDT = {}
	sets.engaged.Chango.Fodder.PDT = {}

	sets.engaged.Chango.PDT.Adoulin = {}
	sets.engaged.Chango.SomeAcc.PDT.Adoulin = {}
	sets.engaged.Chango.Acc.PDT.Adoulin = {}
	sets.engaged.Chango.FullAcc.PDT.Adoulin = {}
	sets.engaged.Chango.Fodder.PDT.Adoulin = {}

	sets.engaged.Chango.PDT.AM = {}
	sets.engaged.Chango.SomeAcc.PDT.AM = {}
	sets.engaged.Chango.Acc.PDT.AM = {}
	sets.engaged.Chango.FullAcc.PDT.AM = {}
	sets.engaged.Chango.Fodder.PDT.AM = {}

	sets.engaged.Chango.PDT.Adoulin.AM = {}
	sets.engaged.Chango.SomeAcc.PDT.Adoulin.AM = {}
	sets.engaged.Chango.Acc.PDT.Adoulin.AM = {}
	sets.engaged.Chango.FullAcc.PDT.Adoulin.AM = {}
	sets.engaged.Chango.Fodder.PDT.Adoulin.AM = {}

	sets.engaged.Chango.PDT.Charge = {}
	sets.engaged.Chango.SomeAcc.PDT.Charge = {}
	sets.engaged.Chango.Acc.PDT.Charge = {}
	sets.engaged.Chango.FullAcc.PDT.Charge = {}
	sets.engaged.Chango.Fodder.PDT.Charge = {}

	sets.engaged.Chango.PDT.Adoulin.Charge = {}
	sets.engaged.Chango.SomeAcc.PDT.Adoulin.Charge = {}
	sets.engaged.Chango.Acc.PDT.Adoulin.Charge = {}
	sets.engaged.Chango.FullAcc.PDT.Adoulin.Charge = {}
	sets.engaged.Chango.Fodder.PDT.Adoulin.Charge = {}

	sets.engaged.Chango.PDT.Charge.AM = {}
	sets.engaged.Chango.SomeAcc.PDT.Charge.AM = {}
	sets.engaged.Chango.Acc.PDT.Charge.AM = {}
	sets.engaged.Chango.FullAcc.PDT.Charge.AM = {}
	sets.engaged.Chango.Fodder.PDT.Charge.AM = {}

	sets.engaged.Chango.PDT.Adoulin.Charge.AM = {}
	sets.engaged.Chango.SomeAcc.PDT.Adoulin.Charge.AM = {}
	sets.engaged.Chango.Acc.PDT.Adoulin.Charge.AM = {}
	sets.engaged.Chango.FullAcc.PDT.Adoulin.Charge.AM = {}
	sets.engaged.Chango.Fodder.PDT.Adoulin.Charge.AM = {}

	sets.engaged.Chango.MDT = {}
	sets.engaged.Chango.SomeAcc.MDT = {}
	sets.engaged.Chango.Acc.MDT = {}
	sets.engaged.Chango.FullAcc.MDT = {}
	sets.engaged.Chango.Fodder.MDT = {}

	sets.engaged.Chango.MDT.Adoulin = {}
	sets.engaged.Chango.SomeAcc.MDT.Adoulin = {}
	sets.engaged.Chango.Acc.MDT.Adoulin = {}
	sets.engaged.Chango.FullAcc.MDT.Adoulin = {}
	sets.engaged.Chango.Fodder.MDT.Adoulin = {}

	sets.engaged.Chango.MDT.AM = {}
	sets.engaged.Chango.SomeAcc.MDT.AM = {}
	sets.engaged.Chango.Acc.MDT.AM = {}
	sets.engaged.Chango.FullAcc.MDT.AM = {}
	sets.engaged.Chango.Fodder.MDT.AM = {}

	sets.engaged.Chango.MDT.Adoulin.AM = {}
	sets.engaged.Chango.SomeAcc.MDT.Adoulin.AM = {}
	sets.engaged.Chango.Acc.MDT.Adoulin.AM = {}
	sets.engaged.Chango.FullAcc.MDT.Adoulin.AM = {}
	sets.engaged.Chango.Fodder.MDT.Adoulin.AM = {}

	sets.engaged.Chango.MDT.Charge = {}
	sets.engaged.Chango.SomeAcc.MDT.Charge = {}
	sets.engaged.Chango.Acc.MDT.Charge = {}
	sets.engaged.Chango.FullAcc.MDT.Charge = {}
	sets.engaged.Chango.Fodder.MDT.Charge = {}

	sets.engaged.Chango.MDT.Adoulin.Charge = {}
	sets.engaged.Chango.SomeAcc.MDT.Adoulin.Charge = {}
	sets.engaged.Chango.Acc.MDT.Adoulin.Charge = {}
	sets.engaged.Chango.FullAcc.MDT.Adoulin.Charge = {}
	sets.engaged.Chango.Fodder.MDT.Adoulin.Charge = {}

	sets.engaged.Chango.MDT.Charge.AM = {}
	sets.engaged.Chango.SomeAcc.MDT.Charge.AM = {}
	sets.engaged.Chango.Acc.MDT.Charge.AM = {}
	sets.engaged.Chango.FullAcc.MDT.Charge.AM = {}
	sets.engaged.Chango.Fodder.MDT.Charge.AM = {}

	sets.engaged.Chango.MDT.Adoulin.Charge.AM = {}
	sets.engaged.Chango.SomeAcc.MDT.Adoulin.Charge.AM = {}
	sets.engaged.Chango.Acc.MDT.Adoulin.Charge.AM = {}
	sets.engaged.Chango.FullAcc.MDT.Adoulin.Charge.AM = {}
	sets.engaged.Chango.Fodder.MDT.Adoulin.Charge.AM = {}

    sets.engaged.Chango.Mighty = {}
	sets.engaged.Chango.SomeAcc.Mighty = {}
	sets.engaged.Chango.Acc.Mighty = {}
	sets.engaged.Chango.FullAcc.Mighty = {}
	sets.engaged.Chango.Fodder.Mighty = {}

    sets.engaged.Chango.Adoulin.Mighty = {}
	sets.engaged.Chango.SomeAcc.Adoulin.Mighty = {}
	sets.engaged.Chango.Acc.Adoulin.Mighty = {}
	sets.engaged.Chango.FullAcc.Adoulin.Mighty = {}
	sets.engaged.Chango.Fodder.Adoulin.Mighty = {}

    sets.engaged.Chango.Mighty.AM = {}
	sets.engaged.Chango.SomeAcc.Mighty.AM = {}
	sets.engaged.Chango.Acc.Mighty.AM = {}
	sets.engaged.Chango.FullAcc.Mighty.AM = {}
	sets.engaged.Chango.Fodder.Mighty.AM = {}

    sets.engaged.Chango.Adoulin.Mighty.AM = {}
	sets.engaged.Chango.SomeAcc.Adoulin.Mighty.AM = {}
	sets.engaged.Chango.Acc.Adoulin.Mighty.AM = {}
	sets.engaged.Chango.FullAcc.Adoulin.Mighty.AM = {}
	sets.engaged.Chango.Fodder.Adoulin.Mighty.AM = {}

    sets.engaged.Chango.Charge.Mighty = {}
	sets.engaged.Chango.SomeAcc.Charge.Mighty = {}
	sets.engaged.Chango.Acc.Charge.Mighty = {}
	sets.engaged.Chango.FullAcc.Charge.Mighty = {}
	sets.engaged.Chango.Fodder.Charge.Mighty = {}

    sets.engaged.Chango.Adoulin.Charge.Mighty = {}
	sets.engaged.Chango.SomeAcc.Adoulin.Charge.Mighty = {}
	sets.engaged.Chango.Acc.Adoulin.Charge.Mighty = {}
	sets.engaged.Chango.FullAcc.Adoulin.Charge.Mighty = {}
	sets.engaged.Chango.Fodder.Adoulin.Charge.Mighty = {}

    sets.engaged.Chango.Charge.Mighty.AM = {}
	sets.engaged.Chango.SomeAcc.Charge.Mighty.AM = {}
	sets.engaged.Chango.Acc.Charge.Mighty.AM = {}
	sets.engaged.Chango.FullAcc.Charge.Mighty.AM = {}
	sets.engaged.Chango.Fodder.Charge.Mighty.AM = {}

    sets.engaged.Chango.Adoulin.Charge.Mighty.AM = {}
	sets.engaged.Chango.SomeAcc.Adoulin.Charge.Mighty.AM = {}
	sets.engaged.Chango.Acc.Adoulin.Charge.Mighty.AM = {}
	sets.engaged.Chango.FullAcc.Adoulin.Charge.Mighty.AM = {}
	sets.engaged.Chango.Fodder.Adoulin.Charge.Mighty.AM = {}

	sets.engaged.Chango.PDT.Mighty = {}
	sets.engaged.Chango.SomeAcc.PDT.Mighty = {}
	sets.engaged.Chango.Acc.PDT.Mighty = {}
	sets.engaged.Chango.FullAcc.PDT.Mighty = {}
	sets.engaged.Chango.Fodder.PDT.Mighty = {}

	sets.engaged.Chango.PDT.Adoulin.Mighty = {}
	sets.engaged.Chango.SomeAcc.PDT.Adoulin.Mighty = {}
	sets.engaged.Chango.Acc.PDT.Adoulin.Mighty = {}
	sets.engaged.Chango.FullAcc.PDT.Adoulin.Mighty = {}
	sets.engaged.Chango.Fodder.PDT.Adoulin.Mighty = {}

	sets.engaged.Chango.PDT.Mighty.AM = {}
	sets.engaged.Chango.SomeAcc.PDT.Mighty.AM = {}
	sets.engaged.Chango.Acc.PDT.Mighty.AM = {}
	sets.engaged.Chango.FullAcc.PDT.Mighty.AM = {}
	sets.engaged.Chango.Fodder.PDT.Mighty.AM = {}

	sets.engaged.Chango.PDT.Adoulin.Mighty.AM = {}
	sets.engaged.Chango.SomeAcc.PDT.Adoulin.Mighty.AM = {}
	sets.engaged.Chango.Acc.PDT.Adoulin.Mighty.AM = {}
	sets.engaged.Chango.FullAcc.PDT.Adoulin.Mighty.AM = {}
	sets.engaged.Chango.Fodder.PDT.Adoulin.Mighty.AM = {}

	sets.engaged.Chango.PDT.Charge.Mighty = {}
	sets.engaged.Chango.SomeAcc.PDT.Charge.Mighty = {}
	sets.engaged.Chango.Acc.PDT.Charge.Mighty = {}
	sets.engaged.Chango.FullAcc.PDT.Charge.Mighty = {}
	sets.engaged.Chango.Fodder.PDT.Charge.Mighty = {}

	sets.engaged.Chango.PDT.Adoulin.Charge.Mighty = {}
	sets.engaged.Chango.SomeAcc.PDT.Adoulin.Charge.Mighty = {}
	sets.engaged.Chango.Acc.PDT.Adoulin.Charge.Mighty = {}
	sets.engaged.Chango.FullAcc.PDT.Adoulin.Charge.Mighty = {}
	sets.engaged.Chango.Fodder.PDT.Adoulin.Charge.Mighty = {}

	sets.engaged.Chango.PDT.Charge.Mighty.AM = {}
	sets.engaged.Chango.SomeAcc.PDT.Charge.Mighty.AM = {}
	sets.engaged.Chango.Acc.PDT.Charge.Mighty.AM = {}
	sets.engaged.Chango.FullAcc.PDT.Charge.Mighty.AM = {}
	sets.engaged.Chango.Fodder.PDT.Charge.Mighty.AM = {}

	sets.engaged.Chango.PDT.Adoulin.Charge.Mighty.AM = {}
	sets.engaged.Chango.SomeAcc.PDT.Adoulin.Charge.Mighty.AM = {}
	sets.engaged.Chango.Acc.PDT.Adoulin.Charge.Mighty.AM = {}
	sets.engaged.Chango.FullAcc.PDT.Adoulin.Charge.Mighty.AM = {}
	sets.engaged.Chango.Fodder.PDT.Adoulin.Charge.Mighty.AM = {}

	sets.engaged.Chango.MDT.Mighty = {}
	sets.engaged.Chango.SomeAcc.MDT.Mighty = {}
	sets.engaged.Chango.Acc.MDT.Mighty = {}
	sets.engaged.Chango.FullAcc.MDT.Mighty = {}
	sets.engaged.Chango.Fodder.MDT.Mighty = {}

	sets.engaged.Chango.MDT.Adoulin.Mighty = {}
	sets.engaged.Chango.SomeAcc.MDT.Adoulin.Mighty = {}
	sets.engaged.Chango.Acc.MDT.Adoulin.Mighty = {}
	sets.engaged.Chango.FullAcc.MDT.Adoulin.Mighty = {}
	sets.engaged.Chango.Fodder.MDT.Adoulin.Mighty = {}

	sets.engaged.Chango.MDT.Mighty.AM = {}
	sets.engaged.Chango.SomeAcc.MDT.Mighty.AM = {}
	sets.engaged.Chango.Acc.MDT.Mighty.AM = {}
	sets.engaged.Chango.FullAcc.MDT.Mighty.AM = {}
	sets.engaged.Chango.Fodder.MDT.Mighty.AM = {}

	sets.engaged.Chango.MDT.Adoulin.Mighty.AM = {}
	sets.engaged.Chango.SomeAcc.MDT.Adoulin.Mighty.AM = {}
	sets.engaged.Chango.Acc.MDT.Adoulin.Mighty.AM = {}
	sets.engaged.Chango.FullAcc.MDT.Adoulin.Mighty.AM = {}
	sets.engaged.Chango.Fodder.MDT.Adoulin.Mighty.AM = {}

	sets.engaged.Chango.MDT.Charge.Mighty = {}
	sets.engaged.Chango.SomeAcc.MDT.Charge.Mighty = {}
	sets.engaged.Chango.Acc.MDT.Charge.Mighty = {}
	sets.engaged.Chango.FullAcc.MDT.Charge.Mighty = {}
	sets.engaged.Chango.Fodder.MDT.Charge.Mighty = {}

	sets.engaged.Chango.MDT.Adoulin.Charge.Mighty = {}
	sets.engaged.Chango.SomeAcc.MDT.Adoulin.Charge.Mighty = {}
	sets.engaged.Chango.Acc.MDT.Adoulin.Charge.Mighty = {}
	sets.engaged.Chango.FullAcc.MDT.Adoulin.Charge.Mighty = {}
	sets.engaged.Chango.Fodder.MDT.Adoulin.Charge.Mighty = {}

	sets.engaged.Chango.MDT.Charge.Mighty.AM = {}
	sets.engaged.Chango.SomeAcc.MDT.Charge.Mighty.AM = {}
	sets.engaged.Chango.Acc.MDT.Charge.Mighty.AM = {}
	sets.engaged.Chango.FullAcc.MDT.Charge.Mighty.AM = {}
	sets.engaged.Chango.Fodder.MDT.Charge.Mighty.AM = {}

	sets.engaged.Chango.MDT.Adoulin.Charge.Mighty.AM = {}
	sets.engaged.Chango.SomeAcc.MDT.Adoulin.Charge.Mighty.AM = {}
	sets.engaged.Chango.Acc.MDT.Adoulin.Charge.Mighty.AM = {}
	sets.engaged.Chango.FullAcc.MDT.Adoulin.Charge.Mighty.AM = {}
	sets.engaged.Chango.Fodder.MDT.Adoulin.Charge.Mighty.AM = {}

-- Ragnarok melee sets
    sets.engaged.Ragnarok = {}
	sets.engaged.Ragnarok.SomeAcc = {}
	sets.engaged.Ragnarok.Acc = {}
	sets.engaged.Ragnarok.FullAcc = {}
	sets.engaged.Ragnarok.Fodder = {}

    sets.engaged.Ragnarok.Adoulin = {}
	sets.engaged.Ragnarok.SomeAcc.Adoulin = {}
	sets.engaged.Ragnarok.Acc.Adoulin = {}
	sets.engaged.Ragnarok.FullAcc.Adoulin = {}
	sets.engaged.Ragnarok.Fodder.Adoulin = {}

    sets.engaged.Ragnarok.AM = {}
	sets.engaged.Ragnarok.SomeAcc.AM = {}
	sets.engaged.Ragnarok.Acc.AM = {}
	sets.engaged.Ragnarok.FullAcc.AM = {}
	sets.engaged.Ragnarok.Fodder.AM = {}

    sets.engaged.Ragnarok.Adoulin.AM = {}
	sets.engaged.Ragnarok.SomeAcc.Adoulin.AM = {}
	sets.engaged.Ragnarok.Acc.Adoulin.AM = {}
	sets.engaged.Ragnarok.FullAcc.Adoulin.AM = {}
	sets.engaged.Ragnarok.Fodder.Adoulin.AM = {}

    sets.engaged.Ragnarok.Charge = {}
	sets.engaged.Ragnarok.SomeAcc.Charge = {}
	sets.engaged.Ragnarok.Acc.Charge = {}
	sets.engaged.Ragnarok.FullAcc.Charge = {}
	sets.engaged.Ragnarok.Fodder.Charge = {}

    sets.engaged.Ragnarok.Adoulin.Charge = {}
	sets.engaged.Ragnarok.SomeAcc.Adoulin.Charge = {}
	sets.engaged.Ragnarok.Acc.Adoulin.Charge = {}
	sets.engaged.Ragnarok.FullAcc.Adoulin.Charge = {}
	sets.engaged.Ragnarok.Fodder.Adoulin.Charge = {}

    sets.engaged.Ragnarok.Charge.AM = {}
	sets.engaged.Ragnarok.SomeAcc.Charge.AM = {}
	sets.engaged.Ragnarok.Acc.Charge.AM = {}
	sets.engaged.Ragnarok.FullAcc.Charge.AM = {}
	sets.engaged.Ragnarok.Fodder.Charge.AM = {}

    sets.engaged.Ragnarok.Adoulin.Charge.AM = {}
	sets.engaged.Ragnarok.SomeAcc.Adoulin.Charge.AM = {}
	sets.engaged.Ragnarok.Acc.Adoulin.Charge.AM = {}
	sets.engaged.Ragnarok.FullAcc.Adoulin.Charge.AM = {}
	sets.engaged.Ragnarok.Fodder.Adoulin.Charge.AM = {}

	sets.engaged.Ragnarok.PDT = {}
	sets.engaged.Ragnarok.SomeAcc.PDT = {}
	sets.engaged.Ragnarok.Acc.PDT = {}
	sets.engaged.Ragnarok.FullAcc.PDT = {}
	sets.engaged.Ragnarok.Fodder.PDT = {}

	sets.engaged.Ragnarok.PDT.Adoulin = {}
	sets.engaged.Ragnarok.SomeAcc.PDT.Adoulin = {}
	sets.engaged.Ragnarok.Acc.PDT.Adoulin = {}
	sets.engaged.Ragnarok.FullAcc.PDT.Adoulin = {}
	sets.engaged.Ragnarok.Fodder.PDT.Adoulin = {}

	sets.engaged.Ragnarok.PDT.AM = {}
	sets.engaged.Ragnarok.SomeAcc.PDT.AM = {}
	sets.engaged.Ragnarok.Acc.PDT.AM = {}
	sets.engaged.Ragnarok.FullAcc.PDT.AM = {}
	sets.engaged.Ragnarok.Fodder.PDT.AM = {}

	sets.engaged.Ragnarok.PDT.Adoulin.AM = {}
	sets.engaged.Ragnarok.SomeAcc.PDT.Adoulin.AM = {}
	sets.engaged.Ragnarok.Acc.PDT.Adoulin.AM = {}
	sets.engaged.Ragnarok.FullAcc.PDT.Adoulin.AM = {}
	sets.engaged.Ragnarok.Fodder.PDT.Adoulin.AM = {}

	sets.engaged.Ragnarok.PDT.Charge = {}
	sets.engaged.Ragnarok.SomeAcc.PDT.Charge = {}
	sets.engaged.Ragnarok.Acc.PDT.Charge = {}
	sets.engaged.Ragnarok.FullAcc.PDT.Charge = {}
	sets.engaged.Ragnarok.Fodder.PDT.Charge = {}

	sets.engaged.Ragnarok.PDT.Adoulin.Charge = {}
	sets.engaged.Ragnarok.SomeAcc.PDT.Adoulin.Charge = {}
	sets.engaged.Ragnarok.Acc.PDT.Adoulin.Charge = {}
	sets.engaged.Ragnarok.FullAcc.PDT.Adoulin.Charge = {}
	sets.engaged.Ragnarok.Fodder.PDT.Adoulin.Charge = {}

	sets.engaged.Ragnarok.PDT.Charge.AM = {}
	sets.engaged.Ragnarok.SomeAcc.PDT.Charge.AM = {}
	sets.engaged.Ragnarok.Acc.PDT.Charge.AM = {}
	sets.engaged.Ragnarok.FullAcc.PDT.Charge.AM = {}
	sets.engaged.Ragnarok.Fodder.PDT.Charge.AM = {}

	sets.engaged.Ragnarok.PDT.Adoulin.Charge.AM = {}
	sets.engaged.Ragnarok.SomeAcc.PDT.Adoulin.Charge.AM = {}
	sets.engaged.Ragnarok.Acc.PDT.Adoulin.Charge.AM = {}
	sets.engaged.Ragnarok.FullAcc.PDT.Adoulin.Charge.AM = {}
	sets.engaged.Ragnarok.Fodder.PDT.Adoulin.Charge.AM = {}

	sets.engaged.Ragnarok.MDT = {}
	sets.engaged.Ragnarok.SomeAcc.MDT = {}
	sets.engaged.Ragnarok.Acc.MDT = {}
	sets.engaged.Ragnarok.FullAcc.MDT = {}
	sets.engaged.Ragnarok.Fodder.MDT = {}

	sets.engaged.Ragnarok.MDT.Adoulin = {}
	sets.engaged.Ragnarok.SomeAcc.MDT.Adoulin = {}
	sets.engaged.Ragnarok.Acc.MDT.Adoulin = {}
	sets.engaged.Ragnarok.FullAcc.MDT.Adoulin = {}
	sets.engaged.Ragnarok.Fodder.MDT.Adoulin = {}

	sets.engaged.Ragnarok.MDT.AM = {}
	sets.engaged.Ragnarok.SomeAcc.MDT.AM = {}
	sets.engaged.Ragnarok.Acc.MDT.AM = {}
	sets.engaged.Ragnarok.FullAcc.MDT.AM = {}
	sets.engaged.Ragnarok.Fodder.MDT.AM = {}

	sets.engaged.Ragnarok.MDT.Adoulin.AM = {}
	sets.engaged.Ragnarok.SomeAcc.MDT.Adoulin.AM = {}
	sets.engaged.Ragnarok.Acc.MDT.Adoulin.AM = {}
	sets.engaged.Ragnarok.FullAcc.MDT.Adoulin.AM = {}
	sets.engaged.Ragnarok.Fodder.MDT.Adoulin.AM = {}

	sets.engaged.Ragnarok.MDT.Charge = {}
	sets.engaged.Ragnarok.SomeAcc.MDT.Charge = {}
	sets.engaged.Ragnarok.Acc.MDT.Charge = {}
	sets.engaged.Ragnarok.FullAcc.MDT.Charge = {}
	sets.engaged.Ragnarok.Fodder.MDT.Charge = {}

	sets.engaged.Ragnarok.MDT.Adoulin.Charge = {}
	sets.engaged.Ragnarok.SomeAcc.MDT.Adoulin.Charge = {}
	sets.engaged.Ragnarok.Acc.MDT.Adoulin.Charge = {}
	sets.engaged.Ragnarok.FullAcc.MDT.Adoulin.Charge = {}
	sets.engaged.Ragnarok.Fodder.MDT.Adoulin.Charge = {}

	sets.engaged.Ragnarok.MDT.Charge.AM = {}
	sets.engaged.Ragnarok.SomeAcc.MDT.Charge.AM = {}
	sets.engaged.Ragnarok.Acc.MDT.Charge.AM = {}
	sets.engaged.Ragnarok.FullAcc.MDT.Charge.AM = {}
	sets.engaged.Ragnarok.Fodder.MDT.Charge.AM = {}

	sets.engaged.Ragnarok.MDT.Adoulin.Charge.AM = {}
	sets.engaged.Ragnarok.SomeAcc.MDT.Adoulin.Charge.AM = {}
	sets.engaged.Ragnarok.Acc.MDT.Adoulin.Charge.AM = {}
	sets.engaged.Ragnarok.FullAcc.MDT.Adoulin.Charge.AM = {}
	sets.engaged.Ragnarok.Fodder.MDT.Adoulin.Charge.AM = {}

    sets.engaged.Ragnarok.Mighty = {}
	sets.engaged.Ragnarok.SomeAcc.Mighty = {}
	sets.engaged.Ragnarok.Acc.Mighty = {}
	sets.engaged.Ragnarok.FullAcc.Mighty = {}
	sets.engaged.Ragnarok.Fodder.Mighty = {}

    sets.engaged.Ragnarok.Adoulin.Mighty = {}
	sets.engaged.Ragnarok.SomeAcc.Adoulin.Mighty = {}
	sets.engaged.Ragnarok.Acc.Adoulin.Mighty = {}
	sets.engaged.Ragnarok.FullAcc.Adoulin.Mighty = {}
	sets.engaged.Ragnarok.Fodder.Adoulin.Mighty = {}

    sets.engaged.Ragnarok.Mighty.AM = {}
	sets.engaged.Ragnarok.SomeAcc.Mighty.AM = {}
	sets.engaged.Ragnarok.Acc.Mighty.AM = {}
	sets.engaged.Ragnarok.FullAcc.Mighty.AM = {}
	sets.engaged.Ragnarok.Fodder.Mighty.AM = {}

    sets.engaged.Ragnarok.Adoulin.Mighty.AM = {}
	sets.engaged.Ragnarok.SomeAcc.Adoulin.Mighty.AM = {}
	sets.engaged.Ragnarok.Acc.Adoulin.Mighty.AM = {}
	sets.engaged.Ragnarok.FullAcc.Adoulin.Mighty.AM = {}
	sets.engaged.Ragnarok.Fodder.Adoulin.Mighty.AM = {}

    sets.engaged.Ragnarok.Charge.Mighty = {}
	sets.engaged.Ragnarok.SomeAcc.Charge.Mighty = {}
	sets.engaged.Ragnarok.Acc.Charge.Mighty = {}
	sets.engaged.Ragnarok.FullAcc.Charge.Mighty = {}
	sets.engaged.Ragnarok.Fodder.Charge.Mighty = {}

    sets.engaged.Ragnarok.Adoulin.Charge.Mighty = {}
	sets.engaged.Ragnarok.SomeAcc.Adoulin.Charge.Mighty = {}
	sets.engaged.Ragnarok.Acc.Adoulin.Charge.Mighty = {}
	sets.engaged.Ragnarok.FullAcc.Adoulin.Charge.Mighty = {}
	sets.engaged.Ragnarok.Fodder.Adoulin.Charge.Mighty = {}

    sets.engaged.Ragnarok.Charge.Mighty.AM = {}
	sets.engaged.Ragnarok.SomeAcc.Charge.Mighty.AM = {}
	sets.engaged.Ragnarok.Acc.Charge.Mighty.AM = {}
	sets.engaged.Ragnarok.FullAcc.Charge.Mighty.AM = {}
	sets.engaged.Ragnarok.Fodder.Charge.Mighty.AM = {}

    sets.engaged.Ragnarok.Adoulin.Charge.Mighty.AM = {}
	sets.engaged.Ragnarok.SomeAcc.Adoulin.Charge.Mighty.AM = {}
	sets.engaged.Ragnarok.Acc.Adoulin.Charge.Mighty.AM = {}
	sets.engaged.Ragnarok.FullAcc.Adoulin.Charge.Mighty.AM = {}
	sets.engaged.Ragnarok.Fodder.Adoulin.Charge.Mighty.AM = {}

	sets.engaged.Ragnarok.PDT.Mighty = {}
	sets.engaged.Ragnarok.SomeAcc.PDT.Mighty = {}
	sets.engaged.Ragnarok.Acc.PDT.Mighty = {}
	sets.engaged.Ragnarok.FullAcc.PDT.Mighty = {}
	sets.engaged.Ragnarok.Fodder.PDT.Mighty = {}

	sets.engaged.Ragnarok.PDT.Adoulin.Mighty = {}
	sets.engaged.Ragnarok.SomeAcc.PDT.Adoulin.Mighty = {}
	sets.engaged.Ragnarok.Acc.PDT.Adoulin.Mighty = {}
	sets.engaged.Ragnarok.FullAcc.PDT.Adoulin.Mighty = {}
	sets.engaged.Ragnarok.Fodder.PDT.Adoulin.Mighty = {}

	sets.engaged.Ragnarok.PDT.Mighty.AM = {}
	sets.engaged.Ragnarok.SomeAcc.PDT.Mighty.AM = {}
	sets.engaged.Ragnarok.Acc.PDT.Mighty.AM = {}
	sets.engaged.Ragnarok.FullAcc.PDT.Mighty.AM = {}
	sets.engaged.Ragnarok.Fodder.PDT.Mighty.AM = {}

	sets.engaged.Ragnarok.PDT.Adoulin.Mighty.AM = {}
	sets.engaged.Ragnarok.SomeAcc.PDT.Adoulin.Mighty.AM = {}
	sets.engaged.Ragnarok.Acc.PDT.Adoulin.Mighty.AM = {}
	sets.engaged.Ragnarok.FullAcc.PDT.Adoulin.Mighty.AM = {}
	sets.engaged.Ragnarok.Fodder.PDT.Adoulin.Mighty.AM = {}

	sets.engaged.Ragnarok.PDT.Charge.Mighty = {}
	sets.engaged.Ragnarok.SomeAcc.PDT.Charge.Mighty = {}
	sets.engaged.Ragnarok.Acc.PDT.Charge.Mighty = {}
	sets.engaged.Ragnarok.FullAcc.PDT.Charge.Mighty = {}
	sets.engaged.Ragnarok.Fodder.PDT.Charge.Mighty = {}

	sets.engaged.Ragnarok.PDT.Adoulin.Charge.Mighty = {}
	sets.engaged.Ragnarok.SomeAcc.PDT.Adoulin.Charge.Mighty = {}
	sets.engaged.Ragnarok.Acc.PDT.Adoulin.Charge.Mighty = {}
	sets.engaged.Ragnarok.FullAcc.PDT.Adoulin.Charge.Mighty = {}
	sets.engaged.Ragnarok.Fodder.PDT.Adoulin.Charge.Mighty = {}

	sets.engaged.Ragnarok.PDT.Charge.Mighty.AM = {}
	sets.engaged.Ragnarok.SomeAcc.PDT.Charge.Mighty.AM = {}
	sets.engaged.Ragnarok.Acc.PDT.Charge.Mighty.AM = {}
	sets.engaged.Ragnarok.FullAcc.PDT.Charge.Mighty.AM = {}
	sets.engaged.Ragnarok.Fodder.PDT.Charge.Mighty.AM = {}

	sets.engaged.Ragnarok.PDT.Adoulin.Charge.Mighty.AM = {}
	sets.engaged.Ragnarok.SomeAcc.PDT.Adoulin.Charge.Mighty.AM = {}
	sets.engaged.Ragnarok.Acc.PDT.Adoulin.Charge.Mighty.AM = {}
	sets.engaged.Ragnarok.FullAcc.PDT.Adoulin.Charge.Mighty.AM = {}
	sets.engaged.Ragnarok.Fodder.PDT.Adoulin.Charge.Mighty.AM = {}

	sets.engaged.Ragnarok.MDT.Mighty = {}
	sets.engaged.Ragnarok.SomeAcc.MDT.Mighty = {}
	sets.engaged.Ragnarok.Acc.MDT.Mighty = {}
	sets.engaged.Ragnarok.FullAcc.MDT.Mighty = {}
	sets.engaged.Ragnarok.Fodder.MDT.Mighty = {}

	sets.engaged.Ragnarok.MDT.Adoulin.Mighty = {}
	sets.engaged.Ragnarok.SomeAcc.MDT.Adoulin.Mighty = {}
	sets.engaged.Ragnarok.Acc.MDT.Adoulin.Mighty = {}
	sets.engaged.Ragnarok.FullAcc.MDT.Adoulin.Mighty = {}
	sets.engaged.Ragnarok.Fodder.MDT.Adoulin.Mighty = {}

	sets.engaged.Ragnarok.MDT.Mighty.AM = {}
	sets.engaged.Ragnarok.SomeAcc.MDT.Mighty.AM = {}
	sets.engaged.Ragnarok.Acc.MDT.Mighty.AM = {}
	sets.engaged.Ragnarok.FullAcc.MDT.Mighty.AM = {}
	sets.engaged.Ragnarok.Fodder.MDT.Mighty.AM = {}

	sets.engaged.Ragnarok.MDT.Adoulin.Mighty.AM = {}
	sets.engaged.Ragnarok.SomeAcc.MDT.Adoulin.Mighty.AM = {}
	sets.engaged.Ragnarok.Acc.MDT.Adoulin.Mighty.AM = {}
	sets.engaged.Ragnarok.FullAcc.MDT.Adoulin.Mighty.AM = {}
	sets.engaged.Ragnarok.Fodder.MDT.Adoulin.Mighty.AM = {}

	sets.engaged.Ragnarok.MDT.Charge.Mighty = {}
	sets.engaged.Ragnarok.SomeAcc.MDT.Charge.Mighty = {}
	sets.engaged.Ragnarok.Acc.MDT.Charge.Mighty = {}
	sets.engaged.Ragnarok.FullAcc.MDT.Charge.Mighty = {}
	sets.engaged.Ragnarok.Fodder.MDT.Charge.Mighty = {}

	sets.engaged.Ragnarok.MDT.Adoulin.Charge.Mighty = {}
	sets.engaged.Ragnarok.SomeAcc.MDT.Adoulin.Charge.Mighty = {}
	sets.engaged.Ragnarok.Acc.MDT.Adoulin.Charge.Mighty = {}
	sets.engaged.Ragnarok.FullAcc.MDT.Adoulin.Charge.Mighty = {}
	sets.engaged.Ragnarok.Fodder.MDT.Adoulin.Charge.Mighty = {}

	sets.engaged.Ragnarok.MDT.Charge.Mighty.AM = {}
	sets.engaged.Ragnarok.SomeAcc.MDT.Charge.Mighty.AM = {}
	sets.engaged.Ragnarok.Acc.MDT.Charge.Mighty.AM = {}
	sets.engaged.Ragnarok.FullAcc.MDT.Charge.Mighty.AM = {}
	sets.engaged.Ragnarok.Fodder.MDT.Charge.Mighty.AM = {}

	sets.engaged.Ragnarok.MDT.Adoulin.Charge.Mighty.AM = {}
	sets.engaged.Ragnarok.SomeAcc.MDT.Adoulin.Charge.Mighty.AM = {}
	sets.engaged.Ragnarok.Acc.MDT.Adoulin.Charge.Mighty.AM = {}
	sets.engaged.Ragnarok.FullAcc.MDT.Adoulin.Charge.Mighty.AM = {}
	sets.engaged.Ragnarok.Fodder.MDT.Adoulin.Charge.Mighty.AM = {}



	--Extra Special Sets

	sets.buff.Doom = set_combine(sets.buff.Doom, {})
	sets.buff.Retaliation = {}
	sets.buff.Restraint = {}
	sets.TreasureHunter = set_combine(sets.TreasureHunter, {})

	-- Weapons sets
	sets.weapons.Ukonvasara = {main="Ukonvasara", sub="Utu Grip"}
  sets.weapons.Chango = {main="Chango", sub="Utu Grip"}
	sets.weapons.DualWeapons = {main="Firangi",sub="Reikiko"}
	sets.weapons.Greatsword = {main="Montante +1",sub="Utu Grip"}
	sets.weapons.ProcDagger = {main="Twilight Knife",sub=empty}
	sets.weapons.ProcSword = {main="Hannibal's Sword",sub=empty}
	sets.weapons.ProcGreatSword = {main="Kriegsmesser",sub=empty}
	sets.weapons.ProcScythe = {main="Ark Scythe",sub=empty}
	sets.weapons.ProcPolearm = {main="Iron Ram Lance",sub=empty}
	sets.weapons.ProcGreatKatana = {main="Mutsunokami",sub=empty}
  sets.weapons.ProcKatana = {main="Debahocho +1",neck="Yarak Torque"}
	sets.weapons.ProcClub = {main="Moogle Wand",sub=empty}
	sets.weapons.ProcStaff = {main="Earth Staff",sub=empty}
  sets.weapons.ShiningOne = {main="Shining One",sub="Utu Grip"}
  sets.weapons.MurderClub = {main="Beryllium Mace +1",sub="Blurred Shield +1"}
  sets.weapons.SwordAndBoard = {main="Naegling",sub="Blurred Shield +1"}
  sets.weapons.LatentBreak = {main="Sturdy Axe", sub="Utu Grip"}

end

-- Select default macro book on initial load or subjob change.
function select_default_macro_book()
    -- Default macro set/book
    if player.sub_job == 'SAM' then
        set_macro_page(7, 1)
    elseif player.sub_job == 'DNC' then
        set_macro_page(7, 1)
    elseif player.sub_job == 'THF' then
        set_macro_page(7, 1)
    else
        set_macro_page(7, 1)
    end
end

function set_lockstyle()
    send_command('wait 2; input /lockstyleset ' .. lockstyleset)
end
